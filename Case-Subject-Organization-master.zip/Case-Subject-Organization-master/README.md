# Case-Subject-Organization

This was a Topic Modeling project. We have a support ticket system with multiple options for the topic - including "Other". The "Other" option was being chosen too often so our team was tasked with creating a Machine Learning model to bin tickets into categories automatically based on the subject and description of the ticket.
